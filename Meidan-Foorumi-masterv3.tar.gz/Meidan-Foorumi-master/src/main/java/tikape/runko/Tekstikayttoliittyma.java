package tikape.runko;

import java.util.Scanner;
import java.util.*;
import tikape.runko.database.AlueDao;

public class Tekstikayttoliittyma {
    private Scanner lukija;
    
    //Insert constructor here
    
    //Luo Dao-oliot
    
    //Tarjoa käyttäjälle eri toiminnallisuuksia
    //esim. näytä kaikki Alueet
    
    // Toteuta toiminta Daojen avulla
    //esim. alueDao.etsiKaikki();
}
