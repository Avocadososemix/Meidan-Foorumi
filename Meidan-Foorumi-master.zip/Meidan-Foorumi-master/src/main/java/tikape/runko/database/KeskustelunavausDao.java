/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.database;

import java.sql.SQLException;
import java.util.List;
import tikape.runko.domain.Keskustelunavaus;

/**
 *
 * @author nikkaire
 */
public class KeskustelunavausDao implements Dao<Keskustelunavaus, Integer>{

    @Override
    public List<Keskustelunavaus> etsiKaikki() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tallenna(Keskustelunavaus Element) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Keskustelunavaus> etsiTietyt(Integer key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
