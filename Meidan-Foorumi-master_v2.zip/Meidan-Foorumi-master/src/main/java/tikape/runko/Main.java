
package tikape.runko;

public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        //Luo yhteys tietokantaan foorumi.db
        
        //Anna tietokanta Dao-olioiden käyttöön
    }
    
}
