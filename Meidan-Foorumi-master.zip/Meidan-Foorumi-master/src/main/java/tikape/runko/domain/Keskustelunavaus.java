
package tikape.runko.domain;

public class Keskustelunavaus {
    private Integer id;
    private String otsikko;
    
}
