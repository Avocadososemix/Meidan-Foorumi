
package tikape.runko.domain;

public class Alue {
    private Integer id;
    private String nimi;
    
    public Alue (Integer id, String nimi) {
        this.id = id;
        this.nimi = nimi;
    }
    
    // luo get ja set metodit tänne, Viestiin ja Keskustelunavaukseen (malli EsimerkkiOpiskelija-luokasta)
}
